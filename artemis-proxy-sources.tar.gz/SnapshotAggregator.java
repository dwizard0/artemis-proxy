package com.ussveritas.artemis.proxy.aggregator;

import com.ussveritas.artemis.proxy.model.*;
import com.ussveritas.artemis.proxy.observer.*;
import com.walkertribe.ian.protocol.*;
import com.walkertribe.ian.world.*;
import com.walkertribe.ian.enums.*;
import org.slf4j.*;

import java.util.*;
import java.util.concurrent.locks.*;

public class SnapshotAggregator {
    private static final Logger log = LoggerFactory.getLogger(SnapshotAggregator.class);
    private final ReadWriteLock lock = new ReentrantReadWriteLock();
    
    private final World world = new World();
    private volatile ShipSnapshot currentSnapshot;
    
    public SnapshotAggregator() {
        this.currentSnapshot = ShipSnapshot.createEmpty();
        world.addPacketListener(this::onWorldUpdate);
    }
    
    public void handlePacket(GhostType ghost, ArtemisPacket packet, int shipNumber) {
        lock.writeLock().lock();
        try {
            // Let World process the packet
            world.onPacket(packet);
            
            // Rebuild snapshot from World state
            currentSnapshot = buildSnapshot(shipNumber);
            
        } catch (Exception e) {
            log.error("Error processing packet from {}: {}", ghost, e.getMessage(), e);
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    private void onWorldUpdate(ArtemisPacket packet) {
        // World listener callback - already handled in handlePacket
    }
    
    private ShipSnapshot buildSnapshot(int shipNumber) {
        ArtemisPlayer player = world.getPlayer(shipNumber);
        
        if (player == null) {
            return ShipSnapshot.createEmpty();
        }
        
        return new ShipSnapshot(
            player.getName(),
            player.getShieldsFront(), // Using front as hull proxy
            buildShieldData(player),
            buildWeaponData(player),
            buildSystemPowerData(player)
        );
    }
    
    private ShieldData buildShieldData(ArtemisPlayer player) {
        return new ShieldData(
            player.getShieldsFront(),
            player.getShieldsRear(),
            null, // Port/starboard not in IAN 3.5.1
            null
        );
    }
    
    private WeaponData buildWeaponData(ArtemisPlayer player) {
        List<TubeData> tubes = new ArrayList<>();
        
        for (int i = 0; i < 6; i++) {
            TubeState state = player.getTubeState(i);
            OrdnanceType contents = player.getTubeContents(i);
            float countdown = player.getTubeCountdown(i);
            
            tubes.add(new TubeData(
                i,
                state == TubeState.LOADED,
                contents != null ? contents.name() : null,
                Float.isNaN(countdown) ? null : countdown
            ));
        }
        
        BeamFrequency freq = player.getBeamFrequency();
        
        return new WeaponData(
            tubes,
            new BeamFrequency(freq != null ? freq.ordinal() : null)
        );
    }
    
    private SystemPowerData buildSystemPowerData(ArtemisPlayer player) {
        Float energy = player.getEnergy();
        
        return new SystemPowerData(
            energy, // Reactor energy
            player.getImpulse(), // Engines
            null, // Weapons power not directly available
            null  // Sensors power not directly available
        );
    }
    
    public ShipSnapshot getCurrentSnapshot() {
        lock.readLock().lock();
        try {
            return currentSnapshot;
        } finally {
            lock.readLock().unlock();
        }
    }
}
